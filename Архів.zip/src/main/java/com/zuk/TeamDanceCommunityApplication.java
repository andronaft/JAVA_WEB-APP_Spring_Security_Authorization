package com.zuk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamDanceCommunityApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamDanceCommunityApplication.class, args);
	}

}
