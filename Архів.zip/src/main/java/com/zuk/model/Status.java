package com.zuk.model;

public enum Status {
    ACTIVE, NOT_ACTIVE, DELETED
}
